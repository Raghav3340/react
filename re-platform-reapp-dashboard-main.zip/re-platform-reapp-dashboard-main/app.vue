<template>
  <NuxtLayout />
</template>